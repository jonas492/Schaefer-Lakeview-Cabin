// Placeholder utility if you want to separate API logic later
export async function getBookings() {
  const res = await fetch('/api/bookings');
  return res.json();
}

export async function submitBooking(data) {
  const res = await fetch('/api/book', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  });
  return res.json();
}