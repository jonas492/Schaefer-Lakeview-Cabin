import React from 'react';
import { Calendar as BigCalendar, momentLocalizer } from 'react-big-calendar';
import { addDays } from 'date-fns';
import 'react-big-calendar/lib/css/react-big-calendar.css';
import moment from 'moment';

const localizer = momentLocalizer(moment);

function Calendar({ bookings, onSelectRange }) {
  // Bookings as events: block off ranges
  const events = bookings.map(b => ({
    title: "Booked",
    start: new Date(b.start),
    end: addDays(new Date(b.end), 1),
    allDay: true
  }));

  return (
    <div style={{margin:"18px 0 28px 0"}}>
      <h2 style={{color:"#1976d2"}}>Availability Calendar</h2>
      <BigCalendar
        selectable
        localizer={localizer}
        events={events}
        defaultView="month"
        defaultDate={new Date()}
        views={['month']}
        style={{ height: 530, background:"white", borderRadius:8, boxShadow:"0 1px 8px #1976d215" }}
        onSelectSlot={slotInfo => {
          // Don't allow selection over booked events
          const start = new Date(slotInfo.start);
          const end = new Date(slotInfo.end);
          const isAvailable = !bookings.some(b =>
            (start <= new Date(b.end) && end >= new Date(b.start))
          );
          if (isAvailable) {
            onSelectRange({ start, end });
          } else {
            alert("Those dates are not available. Please choose another range.");
          }
        }}
        eventPropGetter={() => ({
          style: {
            backgroundColor: "#1976d2",
            border: "1px solid #6c757d",
            color: "white",
            fontWeight: 600
          }
        })}
      />
    </div>
  );
}

export default Calendar;