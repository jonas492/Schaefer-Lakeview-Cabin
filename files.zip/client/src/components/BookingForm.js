import React, { useState } from 'react';
import { format } from 'date-fns';

function BookingForm({ selectedRange, bookedDates, onBookingSuccess }) {
  const [form, setForm] = useState({
    name: '',
    email: '',
    phone: '',
    guests: '',
    message: ''
  });
  const [status, setStatus] = useState('');

  const handleChange = e => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!selectedRange || !form.name || !form.email || !form.guests) {
      setStatus("Please select dates and fill out name, email, and guest count.");
      return;
    }
    setStatus("Submitting...");

    const booking = {
      ...form,
      start: selectedRange.start,
      end: selectedRange.end
    };

    try {
      const res = await fetch('/api/book', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(booking)
      });
      if (res.ok) {
        setStatus("Booking successful! Please watch for a confirmation email with payment instructions.");
        setForm({
          name: '',
          email: '',
          phone: '',
          guests: '',
          message: ''
        });
        onBookingSuccess();
      } else {
        setStatus("There was an error submitting your booking. Try again.");
      }
    } catch {
      setStatus("Submission error.");
    }
  };

  return (
    <section style={{
      background:"white",padding:"22px",borderRadius:10,maxWidth:360,
      boxShadow:"0 1px 8px #1976d220", margin:"0 auto 48px auto"
    }}>
      <h2 style={{color:"#1976d2",marginBottom:14}}>Book Your Stay</h2>
      <form onSubmit={handleSubmit}>
        <div style={{marginBottom:12}}>
          <strong>Chosen Dates:</strong><br />
          {selectedRange
            ? `${format(selectedRange.start, 'MMM dd, yyyy')} to ${format(selectedRange.end, 'MMM dd, yyyy')}`
            : <span style={{color:'#bbb'}}>Please select dates on calendar.</span>
          }
        </div>
        <input name="name" placeholder="Your Name" value={form.name} onChange={handleChange} required style={{width:'100%',margin:'6px 0',padding:"6px"}} />
        <input name="email" type="email" placeholder="Your Email" value={form.email} onChange={handleChange} required style={{width:'100%',margin:'6px 0',padding:"6px"}} />
        <input name="phone" placeholder="Phone Number" value={form.phone} onChange={handleChange} style={{width:'100%',margin:'6px 0',padding:"6px"}} />
        <input name="guests" type="number" min="1" max="10" placeholder="Number of Guests (max 10)" value={form.guests} onChange={handleChange} required style={{width:'100%',margin:'6px 0',padding:"6px"}} />
        <textarea name="message" placeholder="Special Requests?" value={form.message} onChange={handleChange} rows={3} style={{width:'100%',margin:'6px 0',padding:"6px"}} />
        <button type="submit" style={{marginTop:14, padding:'10px 16px',background:"#1976d2",color:"#fff",border:"none",borderRadius:4}}>Book</button>
      </form>
      {status && <div style={{marginTop:10,color:status.startsWith('Booking')?'green':'red'}}>{status}</div>}
    </section>
  );
}

export default BookingForm;