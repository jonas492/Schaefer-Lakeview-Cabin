const IMAGES = [
  "/images/beach.jpg",
  "/images/cottage.jpg",
  "/images/sunset-dock.jpg",
  "/images/hiking.jpg",
  "/images/bathroom.jpg",   // New image 5
  "/images/aerial.jpg",     // New image 6
  "/images/deck1.jpg",      // New image 7
  "/images/deck2.jpg"       // New image 8
];